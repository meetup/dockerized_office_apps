.. % $Id: ldap-schema.rst,v 1.2 2009/04/17 12:14:52 stroeder Exp $


:mod:`ldap.schema` Processing LDAPv3 sub schema sub entry
==============================================================

.. module:: ldap.schema
   :synopsis: Processing LDAPv3 sub schema sub entry
.. moduleauthor:: python-ldap project (see http://www.python-ldap.org/)


.. % Author of the module code;

.. _ldap.schema-example:

Examples for ldap.schema
^^^^^^^^^^^^^^^^^^^^^^^^

::

   import ldap.schema
